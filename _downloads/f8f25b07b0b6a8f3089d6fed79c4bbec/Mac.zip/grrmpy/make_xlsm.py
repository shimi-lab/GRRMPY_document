import pathlib
import shutil
import argparse

parser = argparse.ArgumentParser()
parser.add_argument('name')
args = parser.parse_args()

def mkxlsm():
    name = args.name
    toPath = pathlib.Path().cwd()
    folder =toPath/"temp"
    folder.mkdir()
    for i in ["template.py","template.xlsm","operate.ipynb"]:
        fromPath = pathlib.Path(__file__).parent/"template"/i 
        oldpath = toPath/i
        suf = oldpath.suffix
        shutil.copy(fromPath, toPath)
        oldpath.rename(toPath/f"{name}{suf}")
