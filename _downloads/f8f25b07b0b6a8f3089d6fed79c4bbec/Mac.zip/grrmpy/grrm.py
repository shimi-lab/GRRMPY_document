#utf-8
import collections
import itertools
import copy
from pprint import pprint
from numpy import source
import xlsxwriter
import pandas as pd


"""これ以上の結合距離では開裂したとみなす
ex) coefficient:結合の許容度(default coefficient=1.3)
    C-H結合は1.3*(75+32)=139.1nmで結合が開裂
"""
bond_dict ={"Ac":1.86,"Ag":1.39,"Al":1.26,"Am":1.66,"Ar":1.07,"As":1.21,"At":1.47,"Au":1.24,
"B":0.85,"Ba":1.96,"Be":1.02,"Bh":1.41,"Bi":1.51,"Bk":1.66,"Br":1.14,
"C":0.75,"Ca":1.71,"Cd":1.44,"Ce":1.63,"Cf":1.68,"Cl":0.99,"Cm":1.66,"Cn":1.37,"Co":1.11,"Cr":1.22,"Cs":2.32,"Cu":1.20,
"Db":1.49,"Ds":1.28,"Dy":1.67,"Er":1.65,"Es":1.65,"Eu":1.68,"F":0.64,"Fe":1.16,"Fl":1.43,"Fm":1.67,"Fr":2.23,
"Ga":1.24,"Gd":1.69,"Ge":1.24,"H":0.32,"He":0.46,"Hf":1.52,"Ho":1.66,"Hs":1.34,"I":1.33,"In":1.6,"Ir":1.22,
"K":1.96,"Kr":1.1,"La":1.80,"Li":1.33,"Lr":1.61,"Lu":1.62,"Lv":1.75,"Mc":1.62,"Md":1.73,"Mg":1.39,"Mn":1.19,"Mo":1.38,"Mt":1.29,
"N":0.71,"Na":1.60,"Nb":1.47,"Nd":1.74,"Ne":0.96,"Nh":1.36,"Ni":1.10,"No":1.76,"Np":1.71,
"O":0.63,"Og":1.57,"Os":1.29,"P":1.11,"Pa":1.69,"Pb":1.44,"Pd":1.20,"Pm":1.73,"Po":1.45,"Pr":1.76,"Pt":1.23,"Pu":1.72,
"Ra":2.01,"Rb":2.10,"Re":1.31,"Rf":1.57,"Rg":1.21,"Rh":1.25,"Rn":1.42,"Ru":1.25,
"S":1.03,"Sb":1.40,"Sc":1.48,"Se":1.16,"Sg":1.43,"Si":1.16,"Sn":1.40,"Sr":1.85,
"Ta":1.46,"Tb":1.68,"Tc":1.28,"Te":1.36,"Th":1.75,"Ti":1.36,"Tl":1.50,"Tm":1.64,"Ts":1.65,
"U":1.70,"V":1.34,"W":1.37,"Xe":1.35,"Y":1.63,"Yb":1.70,"Zn":1.20,"Zr":1.54}

class Intermediate():
    """EQ,TS,PTの情報をまとめたクラス

    Property:
        eq[class]:EQ_ListLogクラス
        ts[class]:TS_ListLogクラス
        pt[class]:PT_ListLogクラス
        files[dict]: 参照したファイル
        energies[dict]: EQ,TS,PT構造のエネルギー
        structures[dict]:EQ,TS,PT構造座標
        site_symbols[list]:構造中の元素の種類,POSCARの6行目に相当
        natoms[list]:構造中の元素ごとの原子の数,POSCARの7行目に相当
        nnatoms[int]:構造中の原子の総数
        nstructures[dict]:EQ,TS,PTの数
        group_param[dict]:groupingメソッドを使用した際の引数
    Methods:
        grouping: EQ構造をグループ化する
        make_excelfile: EQ,TS,PTのエネルギー等をExcelファイルにまとめる
        make_graphml(静的メソッド): make_excelfileで作成したxlsxファイルからgraphmlファイルを作成する
        __add__: Intermediateクラス同士は足し算できる.足し算する事でデータを結合する事ができる
    """

    def __init__(self,eq_file:str,ts_file:str,pt_file:str=None):
        """引数
        Args:
            eq_file (str): *_EQ_list_logファイルパス
            ts_file (str): *_TS_list_logファイルパス
            pt_file (str): *_PT_list_logファイルパス(任意)
        """
        self.eq = EQ_ListLog(eq_file)
        """EQの情報をまとめたクラス

        method:
            make_xyz_file:EQ構造をxyzファイルに変換する
        """
        self.ts = TS_ListLog(ts_file)
        if pt_file:
            with open(pt_file) as f:
                l = len(f.readlines())
            if l > 1:
                self.pt = PT_ListLog(pt_file)
            else:
                self.pt = _Empty_PT_ListLog(self.eq)
        else:
            self.pt = _Empty_PT_ListLog(self.eq)
    
    @property
    def files(self):
        """参照したファイルを辞書型で返す

        Returns:
            dict[str:list[str]]: {"EQ":[<path>,...],"TS":[<path>,...,"PT":[<path>,...]}
        """
        return {"EQ":self.eq.files,"TS":self.ts.files,"PT":self.pt.files}

    @property
    def energies(self):
        """EQ,TS,PT構造のエネルギーを辞書型で返す

        Returns:
            dict[str:list[float]]: {"EQ":[<energy>,...],"TS":[<energy>,...],"PT":[<energy>,...]}
        """
        return {"EQ":self.eq.energies,"TS":self.ts.energies,"PT":self.pt.energies}

    @property
    def structures(self):
        """EQ,TS,PT構造座標を辞書型で返す

        Returns:
            dict[str:list[str]]: {"EQ":[[<element> <x> <y> <z>],...]"TS":[[<element> <x> <y> <z>],...]"PT":[[<element> <x> <y> <z>],...]}
        """
        return {"EQ":self.eq.structures,"TS":self.ts.structures,"PT":self.pt.structures}

    @property
    def site_symbols(self):
        """構造中の元素の種類,POSCARの6行目に相当

        Returns:
            list[str]: ex)["H","C","O"]
        """
        return self.eq.site_symbols

    @property
    def natoms(self):
        """構造中の元素ごとの原子の数,POSCARの7行目に相当

        Returns:
            list[int]: ex)[6, 6, 3]
        """
        return self.eq.natoms

    @property
    def nnatoms(self):
        """構造中の原子の総数(int)
        """
        return self.eq.nnatoms

    @property
    def group_param(self):
        """groupingメソッドを使った際に用いたtarget引数のリスト

        Returns:
            list[int]: ex)[1,2,3,4,10,12,13,14,17,19]
                        グループ化の際"1-4,10,12-14,17,19"番目の原子をターゲットとした事を示す.
                        !!!grouping, grouped_eqを参照!!!
        """
        return self.eq.group_param

    @property
    def nstructures(self):
        """EQ,TS,PTの構造の数を示した辞書

        Returns:
            dict[str:int]: {"EQ":int,"TS":int,"PT":int}
        """
        return {"EQ":self.eq.nstructures,"TS":self.ts.nstructures,"PT":self.pt.nstructures}

    def grouping(self,target:str=None,coefficient=1.3,xlsxfile=None):
        """同じ構造を持つEQをグループ化する
           self.group_param,self.grouped_eqが更新される

        Args:
            target (str or None): comファイルの原子の並びから"1-5,7,9"のように注目する原子を指定
                                  この場合1,2,3,4,5,7,9番目の原子同士の結合状態が同じ構造をまとめる
                                  (数字は0~でなく1~数える事に注意)Noneの場合全ての原子の結合状態を見る
            coefficient (float):  結合の許容度,数字が大きい程結合しているとみなされるdefault=1.3
        """
        self.eq.grouping(target,coefficient,xlsxfile)

    def _make_data_for_excel_table(self):
        HARTREE = 4.3597447222071*10**-21 #hartree->kJ
        NA = 6.02214076*10**23
        ##node
        if self.eq.grouped_eq:
            group_dict = {eq:i for i, group in enumerate(self.eq.grouped_eq) for eq in group}
        else:
            group_dict = {i:i for i in range(self.eq.nstructures)}
        node_idx = []
        node_group = []
        for key,val in group_dict.items():
            node_idx.append(key)
            node_group.append(val)
        node_name = [f"EQ{i}" for i in node_idx]
        node_energy = [self.eq.energies[i] for i in node_idx]
        node_df = pd.DataFrame(
            {'node':node_idx,
            'name':node_name,
            'group':node_group,
            'E/Hartree':node_energy,
            'E/kJmol-1':list(map(lambda energy:energy*HARTREE*NA,node_energy))})
        node_df['USE'] = True #USEカラムを追加
        ##PT,TS
        def set_pt_ts_data(log_class):
            edge_idx = [i for i in range(log_class.nstructures)]
            edge_name = [f"{log_class._species_type}{i}" for i in edge_idx]
            source =  [i[0] for i in log_class.connections]
            target =  [i[1] for i in log_class.connections]
            forward_e = [(e-self.eq.energies[source_idx])*HARTREE*NA  if isinstance(source_idx,int) else "" for (source_idx,_),e in zip(log_class.connections,log_class.energies)]
            reverse_e = [(e-self.eq.energies[target_idx])*HARTREE*NA  if isinstance(target_idx,int) else "" for (_,target_idx),e in zip(log_class.connections,log_class.energies)]
            edge_df = pd.DataFrame(
                {'edge':edge_idx,
                'name':edge_name,
                'source':source,
                'target':target,
                'E/Hartree':log_class.energies,
                'E/kJmol-1':list(map(lambda energy:energy*HARTREE*NA,log_class.energies)),
                'forward/kJmol-1':forward_e,
                'reverse/kJmol-1':reverse_e
                })
            return edge_df
        pt_df = set_pt_ts_data(self.pt)
        pt_df['USE'] = True #USEカラムを追加
        ts_df = set_pt_ts_data(self.ts)
        ts_df['USE'] = True #USEカラムを追加
        return node_df,pt_df,ts_df

    def make_excelfile(self,save_file="NetWork_Data.xlsx"):
        """エクセルファイルにデータをまとめる.
           作成したxlsxファイルはmake_graphmlメソッドの引数として扱える.

        Args:
            save_file (path): ファイル保存名. Defaults to "NetWork_Data.xlsx".

        Returns:
            xlsx file: エクセルファイル
        """
        def to_table(df,sheet_name):
            if not df.empty:
                df.to_excel(writer, sheet_name=sheet_name, startrow=1, header=False, index=False)
                worksheet = writer.sheets[sheet_name]
                (max_row, max_col) = df.shape
                column_settings = [{'header': column} for column in df.columns]
                worksheet.add_table(0, 0, max_row, max_col - 1, {'columns': column_settings})
                worksheet.set_column(0, max_col - 1, 12)
        #Excelへ書き込み
        try:
            node_df,pt_df,ts_df = self._make_data_for_excel_table()
            writer = pd.ExcelWriter(save_file, engine='xlsxwriter')
            to_table(node_df,"EQ")
            to_table(pt_df,"PT")
            to_table(ts_df,"TS")
            writer.save()
        except PermissionError:
            print("エラー:保存先のExcelファイルを開きっぱなしにしている??")

    def make_xyz_file(self,file="Structure.xyz",idx_list=None,group=None,group_list=None):
        self.eq.make_xyz_file(file=file,idx_list=idx_list,group=group,group_list=group_list)

    def __add__(self,other):
        new = copy.deepcopy(self)
        new.eq = self.eq + other.eq
        new.pt = self.pt + other.pt
        new.ts = self.ts + other.ts
        #TSのconnections
        n = self.eq.nstructures
        def other_connections(attr):
            other_connections = [(i[0]+n if isinstance(i[0], int) else i[0], 
                                    i[1]+n if isinstance(i[1], int) else i[1]) 
                                    for i in other.__getattribute__(attr).connections]
            return other_connections
        other_ts_connections = other_connections("ts")
        new.ts._set_connection(self.ts.connections + other_ts_connections)
        #PTのconnections
        other_pt_connections = other_connections("pt")
        new.pt._set_connection(self.pt.connections + other_pt_connections)
        return new

class _EQ_PT_TS_ParentClass():
    """EQ_ListLog,PT_TS_ParentClassクラスの親クラス
       ユーザーがこれを直接インスタンス化することはない
    """
    def __init__(self,file):
        self._species_type : str #"EQ"or"PT"or"TS" 子クラス内で定義
        self.__files = [file]
        (self._file_text,
        self.__site_symbols,
        self.__natoms,
        self.__nnatoms,
        self.__energies,
        self.__structures,
        self._site_symbols_v2,
        self.__nstructures) = self._calc_property()
    
    @property
    def files(self):
        """参照したlogファイルのパス

        Returns:
            list[str]: リストの中に格納される
        """
        return self.__files
    def _set_file(self,file:str):
        self.__files  = file

    @property
    def energies(self):
        """*list_logファイルから読み取ったエネルギー

        Returns:
            list[float]: リストで返す
        """
        return self.__energies
    def _set_energies(self,energies:list):
        self.__energies = energies

    @property
    def structures(self):
        """*list_logファイルから読み取った構造の座標

        Returns:
            list[str]: 構造座標のリストを返す
        """
        return self.__structures
    def _set_structures(self,structures):
        self.__structures =structures

    @property
    def natoms(self):
        """構造中の元素ごとの原子の数,POSCARの7行目に相当

        Returns:
            list[int]: ex)[6,6,3]
        """
        return self.__natoms
    def _set_natoms(self,natoms):
        self.__natoms = natoms

    @property
    def nnatoms(self):
        """構造中の原子の数(int)
        """
        return self.__nnatoms
    def _set_nnatioms(self,nnatoms):
        self.__nnatoms = nnatoms

    @property
    def site_symbols(self):
        """構造中の元素の種類,POSCARの6行目に相当

        Returns:
            list[str]: ex)["C","H","O"]
        """
        return self.__site_symbols
    def _set_site_symbols(self,site_symbols):
        self.__site_symbols = site_symbols

    @property
    def nstructures(self):
        """*list_ligから読み取った構造の数(int)
        """
        return self.__nstructures
    def _set_nstructures(self,nstructures:int):
        self.__nstructures = nstructures

    def _calc_property(self):
        with open(self.files[0]) as f:
            log_file_text = f.readlines()
        if self._input_file_check(log_file_text):
            init_index = [i for i,text in enumerate(log_file_text) if "#" in text]
            fin_index = [i for i,text in enumerate(log_file_text) if "Energy    =" in text]
            if len(init_index)*2 == len(fin_index):
                fin_index = [i for i in fin_index if i%2 == 0]
            _site_symbols_v2 = [text.split()[0] for text in log_file_text[3:fin_index[0]]]
            natoms = list(collections.Counter(_site_symbols_v2).values())
            site_symbols = list(collections.Counter(_site_symbols_v2).keys())
            nnatoms = sum(natoms)
            energies = [float(log_file_text[i].split()[2]) for i in fin_index]
            structures = [log_file_text[i+1:i+nnatoms+1] for i in init_index]
            nstructures = len(structures)
            print(f"{self._species_type}の読み込みOK!")
        return log_file_text,site_symbols,natoms,nnatoms,energies, structures,_site_symbols_v2,nstructures

    def _input_file_check(self,log_file_text):
        if self._species_type == "EQ":
            boolian = "List of Equilibrium Structures" in log_file_text[0]
        elif self._species_type == "PT":
            boolian = "List of Path Top (Approximate TS) Structures" in log_file_text[0]
        elif self._species_type == "TS":
            boolian = "List of Transition Structures" in log_file_text[0]
        if boolian:
            return True
        else:
            raise ListLogFileError("ファイルが間違っています")

    def make_xyz_file(self,file:str="Structure.xyz",idx_list=None,group_list=None):
        """化学構造をxyzファイルに変換する

        Args:
            file (str): 保存ファイルパス. Defaults to "Structure.xyz".
            idx_list (list or tuple or None): [1,2,5]とした場合EQ1,EQ2,EQ5の構造がxyzファイルに変換される
                                              指定しない(None)場合,全ての構造がxyzファイルに変換される
                                              Defaults to None.
        """
        if idx_list:
            group_list = group_list if group_list is not None else ["" for _ in idx_list]
            with open(file,"w") as f:
                for idx,g_name in zip(idx_list,group_list):
                    f.write(f"{self.nnatoms}\n{g_name} {self._species_type}{idx}\n") 
                    f.writelines(self.structures[idx])
        else:
            with open(file,"w") as f:
                for idx,structure in enumerate(self.structures):
                    f.write(f"{self.nnatoms}\n{self._species_type}{idx}\n") 
                    f.writelines(structure)

    def __add__(self,other):
        if self.natoms == other.natoms and self.site_symbols == other.site_symbols:
            new = copy.deepcopy(self)
            new._set_file(self.files + other.files)
            new._set_energies(self.energies + other.energies)
            new._set_structures(self.structures + other.structures)
            new._set_nstructures(self.nstructures + other.nstructures)
            return new
        else:
            raise ListLogFileError("異なる種類の構造です")

class EQ_ListLog(_EQ_PT_TS_ParentClass):
    """EQ_ListLog

    Args:
        log_file(path(str)):EQ_list.logのパス,複数してい可(可変長引数)
    Property:
        energies(list):エネルギーのリスト
        structures(generator):構造を返すジェネレーターオブジェクト
        natoms(list):原子の数のリスト,POSCARの6行目に相当
        nnatoms(int):原子の総数
        site_symbols(list):元素の種類のリスト,POSCARの7行目に相当
        grouped_eq(list):グループ化されたEQ(deffault=None)
    Method:
        grouping: 同じ構造を持つEQをグループ化する
        make_xyz_file: EQ構造をxyzファイルに変換する
    """
    def __init__(self,log_file):
        self._species_type = "EQ"
        super().__init__(log_file)
        self.__grouped_eq = None
        self.__grouped_energy = None
        self.__group_param = None
        self.grouped_nstructures: int
        self._bonding_list = None

    @property
    def grouped_eq(self):
        """グループ化されたEQのインデックス番号

        Returns:
            list[list[int]]: ex)[[0,1,2,4],[3],[5,7],[6]]
        """
        return self.__grouped_eq
    def _set_grouped_eq(self,grouped_eq):
        self.__grouped_eq = grouped_eq

    @property
    def grouped_energy(self):
        return self.__grouped_energy
    def _set_grouped_energy(self,grouped_energy):
        self.__grouped_energy = grouped_energy

    @property
    def group_param(self):
        return self.__group_param
    def _set_group_param(self,target,coefficient):
        self.__group_param = {"target":target,"coefficient":coefficient}

    @property
    def grouped_nstructures(self):
        return len(self.grouped_eq)

    def make_xyz_file(self,file="Structure.xyz",idx_list=None,group=None,group_list=None):
        """EQ_list.logから読み取ったEQ構造をxyzファイルに変換する

        Args:
            file (str): 保存ファイル名. 指定しない場合"Structure.xyz".
            idx_list (_type_, optional): _description_. Defaults to None.
            grouped (bool): Trueとした場合,グループ化したEQ構造からxyzファイルを作成する.
                            事前にgroupingメソッドを使ってEQ構造をグループ化する必要がある.
            all (bool): Trueの場合,全てのEQ構造をxyzファイルに変換する.Falseの場合,グループ化した代表的なEQ構造のみをxyzデータに変換する.
        """
        
        if group == "all":
            if self.grouped_eq is not None:
                grouped_eq_list =  list(itertools.chain.from_iterable(self.grouped_eq)) #[[0,1,3],[2,4,5],[6],[7,8]]->[0,1,3,2,4,5,6,7,8]
                grouped_name = [f"G{i}" for i,eq_idx in enumerate(self.grouped_eq) for _ in range(len(eq_idx))] #[G0,G0,G0,G1,G1,G1,G2,G3,G3]
                with open(file,"w") as f:
                    for eq_idx,g_idx in zip(grouped_eq_list,grouped_name):
                        f.write(f"{self.nnatoms}\n{g_idx}(EQ{eq_idx})\n") 
                        f.writelines(self.structures[eq_idx])
            else:
                print("grouping()していないためgroup='all'は使用できません．\n group='all'を消して下さい")
        elif  group == "one":
            if self.grouped_eq is not None:
                grouped_eq_list = [i[0] for i in self.grouped_eq]
                with open(file,"w") as f:
                    for g_idx,eq_idx, in enumerate(grouped_eq_list):
                        f.write(f"{self.nnatoms}\nG{g_idx}(EQ{eq_idx})\n") 
                        f.writelines(self.structures[eq_idx])
            else:
                print("grouping()していないためgroup='all'は使用できません．\n group='one'を消して下さい")
        else:
            super().make_xyz_file(file=file,idx_list=idx_list,group_list=group_list)


    def grouping(self,target=None,coefficient=1.3,xlsxfile=None):
        """同じ構造を持つEQをグループ化する
           self.group_param,self.grouped_eqが更新される

        Args:
            target (str or None): comファイルの原子の並びから"1-5,7,9"のように注目する原子を指定
                                  この場合1,2,3,4,5,7,9番目の原子同士の結合状態が同じ構造をまとめる
                                  (数字は0~でなく1~数える事に注意)Noneの場合全ての原子の結合状態を見る
            coefficient (float):  結合の許容度,数字が大きい程結合しているとみなされるdefault=1.3
        """
        if xlsxfile:
            """Excelファイルをインポートしてグループ化を行なう方法(調整中)"""
            group_param = self.group_param  #group_paramは更新されない
            bonding_list = self._bonding_list  #bonding_listは更新されない
            eq_df = pd.read_excel(xlsxfile, sheet_name="EQ", index_col=None,usecols=[0,1,2,3,4])  #読み込み
            unique_group = eq_df['group'].unique() #ユニークなグループを抽出(list)
            grouped_eq = []
            grouped_energy = []
            for unique in unique_group:
                unique_df = eq_df[eq_df["group"] == unique]  #同じグループである表を抽出する
                unique_df = unique_df.sort_values('node')  #ソート(昇順)
                grouped_eq.append(list(unique_df["node"]))
                grouped_energy.append(list(unique_df["E/Hartree"]))
        else:
            """自動的にグループ化を行なう方法"""
            if target:
                target = [[int(i)-1] if not "-"  in i
                        else [j for j in range(int(i.split("-")[0])-1,int(i.split("-")[1]))]
                        for i in target.split(",")] # "1-5,7,9" -> [[0,1,2,3,4],[6],[8]]
                target = list(itertools.chain.from_iterable(target)) #[[0,1,2,3,4],[6],[8]] -> [0,1,2,3,4,6,8]
            else:
                target = [i for i in range(self.nnatoms)] #[0,1,2,3,...]
            ###各EQの結合状態をbonding_listに格納する###
            bonding_list = [] #[((1,2),(3,5)),((2,4),(2,3)),] この場合EQ0の1,2番目の原子と3,5番目の原子が結合している
            for structure in self.structures:
                bonding = ()
                for a,b in itertools.combinations(target, 2):
                    atom_a = structure[a]
                    atom_b = structure[b]
                    symbol_a,x_a,y_a,z_a = atom_a.split()
                    symbol_a,x_a,y_a,z_a = symbol_a,float(x_a),float(y_a),float(z_a)
                    symbol_b,x_b,y_b,z_b = atom_b.split()
                    symbol_b,x_b,y_b,z_b = symbol_b,float(x_b),float(y_b),float(z_b)
                    distance = ((x_a-x_b)**2+(y_a-y_b)**2+(z_a-z_b)**2)**0.5
                    distance_std = (bond_dict[symbol_a]+bond_dict[symbol_b])*coefficient
                    if distance < distance_std:
                        bonding+=((a,b),)
                bonding_list.append(bonding)
                
            unique_num_bond = {bond_num:i for i,bond_num in enumerate(collections.Counter(bonding_list).keys())}
            unique_num_bond_idx = [[]for _ in range(len(unique_num_bond))]
            for i, bond_num in enumerate(bonding_list):
                idx = unique_num_bond[bond_num]
                unique_num_bond_idx[idx].append(i)
            ele_bond = [tuple(sorted([tuple(sorted([self._site_symbols_v2[b],self._site_symbols_v2[a]])) for a,b in bonding_list[i[0]]])) for i in unique_num_bond_idx]
            unique_ele_bond = {bond_ele:i for i,bond_ele in enumerate(collections.Counter(ele_bond).keys())}
            unipue_ele_bond_idx = [[] for _ in range(len(unique_ele_bond))]
            for i, ele in enumerate(ele_bond):
                idx = unique_ele_bond[ele]
                unipue_ele_bond_idx[idx].append(i)
            flat = list(itertools.chain.from_iterable(unipue_ele_bond_idx))
            grouped_eq = [unique_num_bond_idx[i] for i in flat]
            grouped_energy = [[self.energies[eq_idx] for eq_idx in group]for group in grouped_eq]  #エネルギーをリスト化する
            group_param = {"target":target,"coefficient":coefficient}

        ###プロパティーに代入する###
        self.__group_param = group_param
        self._bonding_list = bonding_list
        self.__grouped_eq = grouped_eq
        self.__grouped_energy = grouped_energy
    
    def __add__(self,other):
        """足し算後はグループ化した構造は受け継がれない
        """
        new = super().__add__(other)
        new._set_group_param(None,None)
        new._set_grouped_eq(None)
        new._set_grouped_energy(None)
        new._bonding_list = None
        return new

class _PT_TS_ParentClass(_EQ_PT_TS_ParentClass):
    """PT_ListLog,TS_ListLogの親クラス
       ユーザーが直接インスタンス化する事はない
    """
    def __init__(self,log_file):
        super().__init__(log_file)
        self.__connections = self._calc_connection()

    @property
    def connections(self):
        return self.__connections
    def _set_connection(self,connections):
        self.__connections = connections

    def _calc_connection(self):
        return [(int(text.split()[2]) if text.split()[2].isdecimal() else text.split()[2],
                 int(text.split()[4]) if text.split()[4].isdecimal() else text.split()[4])
                 for text in self._file_text
                 if "CONNECTION" in text]
    
    def __add__(self,other):
        new = super().__add__(other)
        return new

class PT_ListLog(_PT_TS_ParentClass):
    """*_PT_list_logファイルの情報をまとめたクラス
    """
    def __init__(self,log_file):
        """*_PT_list_logファイルの情報をまとめたクラス

        Args:
            log_file (str:path): *_PT_list_logファイルパス
        """
        self._species_type = "PT"
        super().__init__(log_file)
        
class TS_ListLog(_PT_TS_ParentClass):
    """*_TS_list_logファイルの情報をまとめたクラス
    """
    def __init__(self,log_file):
        """*_TS_list_logファイルの情報をまとめたクラス

        Args:
            log_file (str:path): *_TS_list_logファイルパス
        """
        self._species_type = "TS"
        super().__init__(log_file)

class _Empty_PT_ListLog(_PT_TS_ParentClass):
    """Speciesクラスのインスタンス化引数pt=Noneだった場合,Species.ptに設定するクラス
       ユーザーが直接インスタンス化することはない
    """
    def __init__(self,eq_listlog_class):
        self._species_type = "PT"
        self._set_file([])
        self._file_text = None
        self._set_site_symbols(eq_listlog_class.site_symbols)
        self._set_natoms(eq_listlog_class.natoms)
        self._set_nnatioms(eq_listlog_class.nnatoms)
        self._set_energies([])
        self._set_structures([])
        self._set_nstructures(0)
        self._set_connection([])

class ListLogFileError(Exception):
    """クラスのインスタンス化の際,引数としたファイルが間違っていたときのためのエラー"""
    pass

class NotGroupedYet(Exception):
    """グループ化していないのにgroupを用いるmethodを利用した時のエラー"""
    pass