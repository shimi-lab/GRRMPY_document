requirements.txtは仮想環境にインストール
xlwingsもインストール

xlwingsのUDF(ユーザー定義関数)を使用するにはWindowsOSでなければならない.(現在のxlwingsがMacOSに非対応のため)

