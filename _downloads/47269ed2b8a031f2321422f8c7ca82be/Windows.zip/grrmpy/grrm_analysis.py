from sys import path_hooks
import xlsxwriter
import pandas as pd
import heapq
import copy
from tqdm import tqdm
import networkx as nx
from pptx import Presentation
from pptx.chart.data import XyChartData         	# XYグラフ用のデータ型を提供するクラス
from pptx.enum.chart import XL_CHART_TYPE       	# グラフの種類を定義するクラス
from pptx.enum.chart import XL_MARKER_STYLE     	# グラフのマーカーの種類を定義するクラス
from pptx.util import Cm

def _make_data_for_search_reactionpath(eq_df,edge_df,group,pt,pt_df):#edge_dfはこの時点ではts_dfの事
    ###nodeの前処理###
    eq_df = eq_df.astype({'node':int,'name':str,'E/Hartree':float,'E/kJmol-1':float})
    group_list = []
    for _,g_name in enumerate(eq_df["group"]):
        try:
            group_list.append(int(g_name))
        except :
            group_list.append(str(g_name))
    eq_df["group"] = group_list     
    eq_df = eq_df.sort_values('node')  #ソート(昇順)
    eq_df = eq_df.reset_index(drop=True) #indexをふり直す
    eq_energy = eq_df["E/kJmol-1"] #EQとenergyの対応リスト
    false_eq_df = eq_df[~eq_df['USE']] #FalseにしたEQ
    false_eq_list = list(false_eq_df["node"]) #考慮しなくないEQ構造のidxを格納したリスト
    if group:
        ###groupの時はeqはdictである事に注意
        unique_group = eq_df['group'].unique() #ユニークなグループを抽出(list)
        eq = {unique:list(eq_df[eq_df["group"] == unique]["node"]) for unique in unique_group} #{group名:[eq_inx,,],,}
        if "nan" in eq.keys():
            eq.pop("nan")
    else:
        eq = [i for i in range(len(eq_df))]
    ###edgeの前処理###
    edge_df = edge_df.astype({'edge':int,'name':str,'E/Hartree':float,'E/kJmol-1':float,'forward/kJmol-1':float,'reverse/kJmol-1':float})
    edge_df = edge_df[edge_df["USE"]] #USEがTrueのみを抽出
    edge_df = edge_df.drop('USE', axis=1)#USEカラムを削除    
    edge_df = edge_df.sort_values('edge')  #ソート(昇順)
    edge_df = edge_df.reset_index(drop=True) #index番号を振り直す
    ts_energy = edge_df["E/kJmol-1"] #TSとenergyの対応リスト
    edge_df = edge_df.sort_values('E/kJmol-1')  #ソート(昇順)
    if pt and not pt_df.empty: # pt==1 or pt==2
        pt_df = pt_df.astype({'edge':int,'name':str,'E/Hartree':float,'E/kJmol-1':float,'forward/kJmol-1':float,'reverse/kJmol-1':float,'USE':bool})
        pt_df = pt_df[pt_df["USE"]] #USEがTrueのみを抽出
        pt_df = pt_df.drop('USE', axis=1)#USEカラムを削除
        pt_df = pt_df.sort_values('edge')  #ソート(昇順)
        pt_df = pt_df.reset_index(drop=True) #index番号を振り直す
        pt_energy = list(pt_df["E/kJmol-1"]) 
        pt_name = list(pt_df["edge"])
        pt_energy = dict(zip(pt_name,pt_energy)) #PTとenergyの対応リスト
        pt_df = pt_df.sort_values('E/kJmol-1')  #ソート(昇順)
        edge_df = pd.concat([edge_df, pt_df]) #表を連結
    if pt == 2 and not pt_df.empty:
        edge_df = edge_df.sort_values('E/kJmol-1')  #表を連結語後,さらにソート(昇順)
    if not pt or pt_df.empty or pt is None:
        pt_energy = []
    edge_df[['source', 'target']] = edge_df[['source', 'target']].apply(pd.to_numeric, errors="coerce")#??やDCなどの文字列があればNaNに変更(この時intでなくfloatになる)
    edge_df = edge_df.dropna().astype({'source': 'int', 'target': 'int'}) #NaNを削除し,同時にfloatをintに戻す
    edge_df = edge_df[edge_df['source']!=edge_df['target']] #self-loopを削除
    edge_df = edge_df[edge_df['forward/kJmol-1']>0] #barrier lessを削除
    edge_df = edge_df[edge_df['reverse/kJmol-1']>0] #barrier lessを削除
    edge_df = edge_df[~edge_df["source"].isin(false_eq_list)]
    edge_df = edge_df[~edge_df["target"].isin(false_eq_list)]

       #使用したくないEQを含むTS,PT構造を削除      
    edge_df = edge_df.reset_index(drop=True) #index番号を振り直す
    s = edge_df.apply( lambda r: set((r['source'], r['target'])), axis=1) #同じ反応経路(parallel edges)を抽出する
    edge_df = edge_df.loc[s.drop_duplicates().index]

    edges = [[] for i in range(len(eq_df))] #nodeと同じ数のリスト
    for _,(_,name,source_df,target_df,_,_,forward,_) in edge_df.iterrows():
        edges[source_df].append([target_df,forward,name])
    for _,(_,name,source_df,target_df,_,_,_,reverse) in edge_df.iterrows():
        edges[target_df].append([source_df,reverse,name])
    
    return eq,edges,eq_energy,pt_energy,ts_energy

def _path_search(eq_n,edges, eq, source, target,group,priority,pseudo_cost=None):
    group_len_cost = 0.001 #group間の移動の際に疑似的に経路長のcostを与える
    def _search_group_name(eq_name:str)->str:#あるEQがどのグループに所属しているのか調べる
        for key,val in eq.items():
            if eq_name in val:
                return key
    
    def innner(que,undecided,barrier_and_path):
        if priority == "energy":
            max_e, path_len, e, path = heapq.heappop(que)
        elif priority == "length":
            path_len, max_e, e, path = heapq.heappop(que)
        if path[-1] in undecided:
            undecided.remove(path[-1])
            for goal, cost, ts_pt in edges[path[-1]]:
                true_cost = cost
                cost = pseudo_cost if pseudo_cost and pseudo_cost > cost else cost
                if goal in undecided:
                    if barrier_and_path[goal][0] > cost:
                        if max_e > cost:
                            maxmax = max_e
                        else:
                            maxmax = cost
                        pathlenlen = path_len + 1
                        ee = true_cost
                        pathpath = path+[ts_pt]+[goal]
                        barrier_and_path[goal] = [maxmax,pathlenlen,ee,pathpath]
                        if priority == "energy":
                            heapq.heappush(que, [maxmax,pathlenlen,ee,pathpath])
                        elif priority == "length":
                            heapq.heappush(que, [pathlenlen,maxmax,ee,pathpath])
        return que,undecided,barrier_and_path

    def _trimming(barrier_and_paths_dict):#余計な経路を削る(最初と最後の余計な同じグループ間の移動)
        new_barrier_and_path = {}
        for key,(max_x,path_len,_,path) in barrier_and_paths_dict.items():
            if len(path) >= 3:
                if path[1] == "same_group":
                    path = path[2:]
            if len(path) > 3:
                if path[-2] == "same_group":
                    path = path[:-2]
            # path = [s for s in path if s != 'same_group']
            new_barrier_and_path[key] = [max_x,path_len,path]
        return new_barrier_and_path

    def innner_for_group(que,undecided,barrier_and_path):
        if priority == "energy":
            max_e, path_len, e, path = heapq.heappop(que)
        elif priority == "length":
            path_len, max_e, e, path = heapq.heappop(que)
        group_name = _search_group_name(path[-1])
        if group_name in undecided:
            g = [i for i in eq[group_name] if i != path[-1]]
            for i in g:
                if priority == "energy":
                    heapq.heappush(que, [max_e, path_len+group_len_cost, e, path+["same_group"]+[i]])
                elif priority == "length":
                    heapq.heappush(que, [path_len+group_len_cost, max_e, e, path+["same_group"]+[i]])
                barrier_and_path[i] = [max_e, path_len, e, path+["same_group"]+[i]]
            undecided.remove(group_name)
        for goal, cost, ts_pt in edges[path[-1]]:
            true_cost = cost
            cost = pseudo_cost if pseudo_cost and pseudo_cost > cost else cost
            for idx_g in undecided:
                if goal in eq[idx_g]:
                    if barrier_and_path[goal][0] > cost:
                        if max_e > cost:
                            maxmax = max_e
                        else:
                            maxmax = cost
                        pathlenlen = path_len + 1
                        ee = true_cost
                        pathpath = path+[ts_pt]+[goal]
                        barrier_and_path[goal] = [maxmax,pathlenlen,ee,pathpath]
                        if priority == "energy":
                            heapq.heappush(que, [maxmax,pathlenlen,ee,pathpath])
                        elif priority == "length":
                            heapq.heappush(que, [pathlenlen,maxmax,ee,pathpath])
        return que,undecided,barrier_and_path

    if group:
        eq_count = eq_n
        barrier_and_path = [[float('inf')] * 3 + [[]] for i in range(eq_count)]
        que = []
        undecided = list(eq.keys())
        ini = eq[source][0] #引数に指定したini_gの代表的なeqをsourceとする
        barrier_and_path[ini] = [0,0,0,[ini]]
        heapq.heappush(que, [0,0,0,[ini]])
        if target is not None:
            while target in undecided and len(que)>0:
                que,undecided,barrier_and_path = innner_for_group(que,undecided,barrier_and_path)
            return _trimming({target:barrier_and_path[eq[target][0]]})
        else:
            while len(undecided) > 0 and len(que)>0:
                que,undecided,barrier_and_path = innner_for_group(que,undecided,barrier_and_path)
            barrier_and_path = {g_name:barrier_and_path[eq_idx] for g_name, eq_idx in [(key,val[0]) for key,val in eq.items()]}
            return _trimming(barrier_and_path)  #returnがdict型である事に注意
    else:
        barrier_and_path = [[float('inf')] * 3 + [[]] for i in range(len(eq))]
        que = []
        undecided = copy.deepcopy(eq)
        barrier_and_path[source] = [0,0,0,[eq[source]]]
        heapq.heappush(que, [0,0,0,[eq[source]]])

        if target is not None:
            while target in undecided and len(que) > 0:
                que,undecided,barrier_and_path = innner(que,undecided,barrier_and_path)
            barrier_and_path[target].pop(2)
            barrier_and_path = {target:barrier_and_path[target]}
            return barrier_and_path
        else:
            while len(undecided) > 0 and len(que) > 0:
                que,undecided,barrier_and_path = innner(que,undecided,barrier_and_path)
            barrier_and_path = {i:[max_e,pathlen,path]for i,(max_e,pathlen,_,path) in enumerate(barrier_and_path)}
            return barrier_and_path

def _pseudo_energy_clc_and_data_organization(eq_n,barrier_and_path,eq,edges,source,target,group,priority,pseudo_energy,eq_energy,pt_energy,ts_energy,write_group_name):
    def _search_group_name(eq_name:str)->str:#あるEQがどのグループに所属しているのか調べる
        for key,val in eq.items():
            if eq_name in val:
                return key
    #律速段階のエネルギーを考慮し再計算
    if pseudo_energy:
        new = {}
        for key,(max_e,_,_) in tqdm(barrier_and_path.items()):
            new |= _path_search(eq_n,edges, eq, source, target=key,group=group,priority=priority,pseudo_cost=max_e)
        barrier_and_path = new

    """結果を整える"""
    barrier_and_path_enegylist = {}
    for key,(max_e, _,path) in barrier_and_path.items():
        energy_list = []
        path_name = []
        for eq_pt_ts in path:
            if isinstance(eq_pt_ts, int):  #EQの時
                group_name = f"({_search_group_name(eq_pt_ts)})" if write_group_name  else ""
                path_name.append(f"EQ{eq_pt_ts}"+group_name)
                energy_list.append(eq_energy[eq_pt_ts])
            elif isinstance(eq_pt_ts, str):
                if eq_pt_ts[:2] == "TS":
                    path_name.append(f"TS{int(eq_pt_ts[2:])}")
                    energy_list.append(ts_energy[int(eq_pt_ts[2:])])
                elif eq_pt_ts[:2] == "PT":
                    path_name.append(f"PT{int(eq_pt_ts[2:])}")
                    energy_list.append(pt_energy[int(eq_pt_ts[2:])])
                elif eq_pt_ts[:2] == "same_group":
                    pass
        barrier_and_path_enegylist[key] = [max_e,path_name,energy_list]
    """barrier_and_path_enegylistの中身
    barrier_and_path_enegylistの中身= {"eq番号 or group名":["律速段階のエネルギー",[反応経路],[反応経路に対応するエネルギー]]}
    """
    return barrier_and_path_enegylist

def search_reactionpath(xlsxfile,source,target=None,group=True,pt=0,priority="energy",pseudo_energy=True)->dir:
    """反応経路を計算する.

    | より律速段階のエネルギーが低い経路且つ,反応経路の短い経路を探索する.(priority="energyの場合"),
    | pseudo_energy=Trueとした場合,律速段階より低いエネルギーで進行する反応であれば,より短い反応を採用する.
    | pseudo_energy=TrueはEQ構造の数に比例したより多くの計算時間を必要とする.

    Args:
        xlsxfile (str): 読みとるxlsxファイルを指定
        source (str,int): 反応物のgroup名
        target (ser,int,optional): 生成物のグループ名,指定しない場合(None),全ての経路を計算する
        group (bool, optional): Trueとした場合,同じgroup間での遷移を可能とする
        pt (int, optional): _description_. 0:PTを含めない,
                                           1:同じCONNECTIONのPT,TSがあった場合,必ずTSを採用する.
                                           2:同じCONNECTIONのPT,TSがあった場合よりエネルギーの低い方を採用する
        priority (str, optional): "energy"とした場合,律速段階のエネルギーが低くなる経路を探索,"length"とした場合,反応経路の短い経路を探索
        pseudo_energy (bool, optional): Trueとした場合,律速段階より低いエネルギーで進行する反応であれば,より短い反応を採用する.

    Returns:
        dir: {"生成物のgroup名":["律速段階のエネルギー",["反応経路"],["各段階でのエネルギー"]]}
    """
    eq_df = pd.read_excel(xlsxfile, sheet_name="EQ", index_col=None,usecols=[0,1,2,3,4])  #読み込み
    edge_df = pd.read_excel(xlsxfile, sheet_name="TS", index_col=None,usecols=[0,1,2,3,4,5,6,7])  #TS情報読み込み
    if pt and "PT" in pd.ExcelFile(xlsxfile).sheet_names:
        pt_df = pd.read_excel(xlsxfile, sheet_name="PT", index_col=None,usecols=[0,1,2,3,4,5,6,7])  #TS情報読み込み
    else:
        pt_df = None
    eq,edges,eq_energy,pt_energy,ts_energy = _make_data_for_search_reactionpath(eq_df,edge_df,group,pt,pt_df)
    eq_n = len(eq_df) #EQの個数
    barrier_and_path = _path_search(eq_n,edges, eq, source, target,group,priority,pseudo_cost=None)
    write_group_name = True if group else False
    return _pseudo_energy_clc_and_data_organization(eq_n,barrier_and_path,eq,edges,source,target,group,priority,pseudo_energy,eq_energy,pt_energy,ts_energy,write_group_name)

def _prepare_graphml_data(xlsxfile,pt):
    eq_df = pd.read_excel(xlsxfile, sheet_name="EQ", index_col=None,usecols=[0,1,2,3,4])
    if pt and "PT" in pd.ExcelFile(xlsxfile).sheet_names:
        pt_df = pd.read_excel(xlsxfile, sheet_name="PT", index_col=None,usecols=[0,1,2,3,4,5,6,7])
    else:
        pt_df = False
    ts_df = pd.read_excel(xlsxfile, sheet_name="TS", index_col=None,usecols=[0,1,2,3,4,5,6,7])
    return eq_df,ts_df,pt_df

def _make_graphml(eq_df,ts_df,pt_df,savefile):
    def make_edge_data(df):
        df = df.sort_values('E/Hartree') #昇順でソート
        ##欠損地の削除(無意味なTS,??,DCなどを削除)
        df[['source', 'target']] = df[['source', 'target']].apply(pd.to_numeric, errors="coerce")#??やDCなどの文字列があればNaNに変更(この時intでなくfloatになる)
        df = df.dropna() #NaNを削除
        df = df.astype({'source': 'int', 'target': 'int'})
        df = df[df['source']!=df['target']] #self-loop(グラフ理論)削除
        df = df.reset_index(drop=True) #index番号を振り直す
        s = df.apply( lambda r: set((r['source'], r['target'])), axis=1) #同じ反応経路(parallel edges)を抽出する
        df = df.loc[s.drop_duplicates().index] #同じ反応経路(parallel edges)の重複を無くす
        data = [(source,target,{'name':name,"interaction":f"{source}-{target}","E/Hartree":energy,"E/kJmol-1":jules_e,"forward":forward,"reverse":reverse,"USE":use})
                    for _,(_,name,source,target,energy,jules_e,forward,reverse,use) in df.iterrows()]
        return data
    """nodeデータの作成"""
    eq_data = [(node,{"name":name,"id":node,"group":f"{group}","E/Hartree":energy,"E/kJmol-1":jules_e,"USE":use})
                for _,(node,name,group,energy,jules_e,use) in eq_df.iterrows()]
    G = nx.Graph()
    G.add_nodes_from(eq_data)    
    if pt_df is not False: #pt_dfがあれば
        """PT_edgeデータの作成"""
        pt_data = make_edge_data(pt_df)
        G.add_edges_from(pt_data)
    """TS_edgeデータの作成"""
    ts_data =  make_edge_data(ts_df)
    G.add_edges_from(ts_data)
    nx.write_graphml_lxml(G,savefile)

def make_graphml(xlsxfile="NetWork_Data.xlsx",pt=True,savefile="NetWork_Data.graphml"):
    """graphml形式のグラフデータを作成する.Cytoscape等のグラフ可視化ツールに利用できる

    Args:
        xlsxfile (xlsx): make_excelfileメソッドで作成したxlsxファイル
        pt (bool): pt=Falseの時,PTデータは使わない.
        savefile (path): 保存ファイル名. Defaults to "NetWork_Data.graphml".
        
    Returns:
        graphml file: graphmlファイル
    """
    eq_df,ts_df,pt_df = _prepare_graphml_data(xlsxfile,pt)
    _make_graphml(eq_df,ts_df,pt_df,savefile)

def make_pltfig(*reac_path):
    pass

def draw(*reac_path,save_file):
    """反応ダイアグラムを作成し,Excelファイルとして出力する.
       search_reactionpathの戻り値として得られる辞書のvalueを引数とする

    Args:
        reac_path: search_reactionpathの戻り値として得られる辞書のvalue,可変長引数
        save_file (str): 保存先のファイル名
    """
    def add_template_sheet(sheet_name):
        sheet = book.add_worksheet(sheet_name)
        sheet.write("A1","EQ,TS,PT",bold_format)
        sheet.write("B1","EnergykJ/mol",bold_format)
        sheet.write_column("G1",["" for _ in range(26)],side_format) #枠線
        sheet.write_column("J1",["" for _ in range(26)],side_format) #枠線
        sheet.write_column("K1",["" for _ in range(26)],side_format) #枠線
        sheet.write("G1","Node",side_bold_format)
        sheet.write("J1","Source",side_bold_format)
        sheet.write("K1","Target",side_bold_format)
        sheet.set_column('E:F', 2.64)  #セル幅設定
        sheet.set_column('H:I', 2.64)  #セル幅設定
        sheet.write_column("E2",[i*2+1 for i in range(25)])
        sheet.write_column("F2",[i*2+2 for i in range(25)])
        sheet.write("H2",'=IF($J$2:$J$26<>"",XLOOKUP($J$2:$J$26,$G:$G,$F:$F,,0,1),"")')
        sheet.write("I2",'=IF($K$2:$K$26<>"",XLOOKUP($K$2:$K$26,$G:$G,$E:$E,,0,1),"")')
        sheet.write("L2",f'=IF($G$2:$G$26<>"",XLOOKUP($G$2:$G$26,$A:$A,$B:$B,,0,1),"")')
        sheet.write_dynamic_array_formula("M2",f'=IF($L$2:$L$26<>"",$L$2:$L$26-$M$1,"")')
        sheet.write_dynamic_array_formula("N2",f'=$M$2:$M$26')
        sheet.write("O2",f'=XLOOKUP($J$2:$J$26,$G:$G,$N:$N,,0,1)')
        sheet.write("P2",f'=XLOOKUP($K$2:$K$26,$G:$G,$N:$N,,0,1)')
        sheet.write("M1",f'=$L$2')
        #グラフ
        chart = book.add_chart({'type': 'scatter', 'subtype': 'straight'})#散布図,マーカーなし
        #X軸の設定
        chart.set_x_axis({
            'visible': False,#横軸は消す
            'name': 'Reaction Coordinate', #ラベル名設定
            'num_font': {'name': 'Arial', 'size': 14,'bold': False},#数値のフォント設定(見えてないが)
            'name_font':{'name': 'Arial', 'size': 14,'bold': False,},#ラベルのフォント設定
            'crossing' : -10000,#軸の交点設定
            'major_tick_mark' : 'inside', #主目盛の向き設定(見えてないが)
            'line': {'none': True} #軸の色と線の太さ設定
        })
        #Y軸の設定
        chart.set_y_axis({
            'name' : "Energy (kJ/mol)", 
            'num_font': {'name': 'Arial', 'size': 14,'bold': False,},
            'name_font': {'name': 'Arial', 'size':14,'bold': False,},
            'crossing' : -10000, 
            'major_gridlines': {'visible': False}, 
            'major_tick_mark' : 'inside',
            'minor_tick_mark': 'inside', 
            'line': {'color': '#000000', 'width': 1.0}#軸の色，太さ
        })
        chart.set_legend({'none': True})#凡例は無し
        chart.set_chartarea({
            'border': {'none': True},#グラフエリアの枠線なし
            'fill':   {'none': True}#グラフエリアの塗りつぶしなし
        })
        chart.set_plotarea({
            'border': {'none': True},#プロットエリアの枠線なし
            # 'fill':   {'none': True}#プロットエリアの塗りつぶしあり
        })
        return sheet,chart

    try:
        book = xlsxwriter.Workbook(save_file)    
        ##枠線フォーマット設定
        side_format = book.add_format()
        side_format.set_left(6)
        side_format.set_right(6)
        side_bold_format = book.add_format({'bold': True})
        side_bold_format.set_left(6)
        side_bold_format.set_right(6)
        bold_format = book.add_format({'bold': True})


        
        """all_pathの記述
        """
        sheet,chart = add_template_sheet("all_path")

        """all_path以外"""
        for path in reac_path:
            try:
                sheet,chart = add_template_sheet(f"{path[1][0]}->{path[1][-1]}")
            except xlsxwriter.exceptions.InvalidWorksheetName:
                sheet,chart = add_template_sheet(f"->{path[1][-1]}")
                print("sheet名が31文字を超えたので別の名前に変更しました")
                print(f"{path[1][0]}->{path[1][-1]}から")
                print(f"->{path[1][-1]}に変更")
            #データ
            sheet.write_column("A2",path[1])
            sheet.write_column("B2",path[2])
            sheet.write_column("G2",path[1],side_format)
            sheet.write_column("J2",path[1][:-1],side_format)
            sheet.write_column("K2",path[1][1:],side_format)
            #破線
            for i,_ in enumerate(path[1],start=2):
                chart.add_series({
                    'categories' : f"='{sheet.name}'!$H${i}:$I${i}",
                    'values' : f"='{sheet.name}'!$O${i}:$P${i}",
                    'line' : {'color': "black", 'width': 1.25,'dash_type': "round_dot"},
                    'marker': {'type': 'none'},
                    'name' : f"='{sheet.name}'!$J${i}:$K${i}", #B1を選択
                    'title' : None
                })
            #実線
            for i,node in enumerate(path[1],start=2):
                if node[:2] == "EQ":
                    line_color = "#000000"
                elif node[:2] == "TS":
                    line_color = "#FF0000"
                elif node[:2] == "PT":
                    line_color = "#008000"
                chart.add_series({
                    'categories' : f"='{sheet.name}'!$E${i}:$F${i}",
                    'values' :f"='{sheet.name}'!$M${i}:$N${i}",
                    'line' : {'color': line_color, 'width': 2},
                    'name' : f"='{sheet.name}'!$G${i}", #B1を選択
                    'title' : None,
                    })
            sheet.insert_chart('A4', chart)
        book.close()
    except xlsxwriter.exceptions.FileCreateError:
        print("xlsxファイルが開いている??")

def _make_powerpoint():
    pass


