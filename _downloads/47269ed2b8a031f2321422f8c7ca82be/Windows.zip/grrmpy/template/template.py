#utf-8
import pathlib
import xlwings as xw
import grrmpy.excel_operator as excel_operator

def main():
    """EQ・TS・PT構造をVESTAで開く"""
    structure_folder = pathlib.Path(__file__).parent/'temp'
    sample = excel_operator.read_pickle(__file__)
    excel_operator.oepn_vesta(sample,structure_folder)

@xw.sub
def book_open():
    """Book起動時"""
    excel_operator.open_book(__file__)

@xw.sub
def book_close():
    """Structureフォルダに溜まったxyzファイルを削除する"""
    excel_operator.del_structurexyz(__file__)

@xw.sub
def import_data():
    """データをインポートのボタンの処理,EQ,PT,TSシートにテーブルを作成する"""
    excel_operator.import_data(__file__)

@xw.sub
def mk_xyz():
    datfile = str(pathlib.Path(__file__).parent/"temp"/"xyzdata.dat")
    sample = excel_operator.read_pickle(__file__)
    excel_operator.mk_xyz(sample,datfile)
    
@xw.sub
def mk_graphml():
    datfile = str(pathlib.Path(__file__).parent/"temp"/"graphmldata.dat")
    excel_operator.make_graphml(datfile)

@xw.func
@xw.arg('source', doc='生成物のEQ番号orグループ名')
@xw.arg('target', doc='反応物のEQ番号orグループ名,指定しない場合は全ての経路を探索\nデフォルト:None')
@xw.arg('group', doc="Trueの場合,Group間ではTS・PTを介さない遷移を許可する\nデフォルト:True")
@xw.arg('pt', doc="0:TSのみ\n1:同じEQを結ぶPT・TSがあった場合TSを採用\n2:同じEQを結ぶPT・TSがあった場合より低エネルギーな方を採用\nデフォルト:1")
@xw.arg('priority', doc="0:律速段階のEaが低い経路を採用\n1:反応ステップの短い方を採用\nデフォルト:0")
@xw.arg('pseudo_energy', doc="True:律速段階のEaより低い限り,より短い反応を採用\nFalse:各EQへは最も低いバリアで到達する\nデフォルト:True")
def reaction(source,target=None,group=True,pt=1,priority=0,pseudo_energy=True):
    try:
        return excel_operator.path(source,target,pt,group,priority,pseudo_energy)
    except KeyError:
        return "ERROR!!:sourceまたはtargetに存在しないキーを与えている??"

@xw.func
@xw.arg('data',ndim=2)
def prepare(data):
    return excel_operator.prepare(data)

@xw.func
@xw.arg('structure',ndim=2,doc="'EQ1','TS1'など")
def energy(structure):
    return excel_operator.energy(structure)

@xw.func
@xw.arg('structure',ndim=2,doc="'EQ1','TS1'など")
def g_name(structure):
    return excel_operator.group(structure)

@xw.func
@xw.arg('structure',ndim=2,doc="'EQ1','TS1'など")
def original(structure):
    return excel_operator.original(structure,__file__)