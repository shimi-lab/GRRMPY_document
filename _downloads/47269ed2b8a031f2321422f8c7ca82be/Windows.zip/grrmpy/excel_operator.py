#utf-8
import xlwings as xw
import pathlib
import itertools
import pickle
import subprocess
import configparser
import pandas as pd
import numpy as np
import copy
import grrmpy.grrm_analysis as grrm_analysis
from grrmpy.grrm import Intermediate,ListLogFileError
from grrmpy.grrm_analysis import _make_data_for_search_reactionpath
from grrmpy.grrm_analysis import _path_search
from grrmpy.grrm_analysis import _pseudo_energy_clc_and_data_organization
from pprint import pprint

def open_book(folder):
    sample = make_intermediate_obj(folder)
    write_pickle(folder,sample)

def del_structurexyz(folder):
    p = pathlib.Path(folder).parent/"temp"
    extension = [".xyz",".pickle",".dat"]
    xyz_and_pickle = [i for i in p.glob('*.*') if i.suffix in extension]
    for file in xyz_and_pickle:
        file.unlink(missing_ok=True)

    app = xw.apps.active 
    """saveも入れる"""
    app.quit()  
    app.kill()


def write_pickle(folder,sample):
    p = pathlib.Path(folder).parent
    with open(f"{p/'temp/temp.pickle'}", "wb") as f:
        pickle.dump(sample,f)

def read_pickle(folder):
    p = pathlib.Path(folder).parent
    with open(f"{p/'temp/temp.pickle'}", "rb") as f:
        sample = pickle.load(f)
    return sample

def _get_names():
    names = xw.books.active.selection.value #選択中のセルの値を取
    if names is None:
        return []
    elif isinstance(names[0],list): #複数行列の値が指定された場合
        names = list(itertools.chain.from_iterable(names)) #1次元化
        names = list(filter(None, names)) #Noneが含まれている部分は削除   
    elif isinstance(names,list): #複数行の値が指定された場合
        names = list(filter(None, names)) #Noneが含まれている部分は削除
    elif isinstance(names,str): # 単一のセルが指定された場合
        names = [names]
    return names

def oepn_vesta(intermediate,structure_folder): #Run main
    """選択中のEQ,TS,PTの構造を返す"""
    p = pathlib.Path(__file__).parent/"template/setting.ini"
    config_ini = configparser.ConfigParser()
    config_ini.read(f"{p}", encoding='utf-8')
    vesta_exe = config_ini["DEFAULT"]["vesta_exe"]
    jmol_path = config_ini["DEFAULT"]["jmol_jar"]
    try:
        names = _get_names()
        if len(names) <= 1:
            name = names[0]
            file = str(structure_folder/f"{name}.xyz")
            src_type = name[:2].lower() #小文字に変換
            if name[2:].isdecimal() and src_type in ["eq","ts","pt"]: #番号とsrc_typeが正常か判断
                i = int(name[2:]) 
                if intermediate.__getattribute__(src_type).nstructures >= i+1: #存在する構造か判断
                    intermediate.__getattribute__(src_type).make_xyz_file(file=file,idx_list=[i])
                    subprocess.Popen([vesta_exe,'-open', file])
        elif len(names) > 1:
            file = str(structure_folder/f"Path.xyz")
            with open(file,"w") as f:
                n_atoms = intermediate.nnatoms
                for name in names:
                    src_type = name[:2].lower() #小文字に変換
                    if name[2:].isdecimal() and src_type in ["eq","ts","pt"]: #番号とsrc_typeが正常か判断
                        i = int(name[2:]) 
                        if intermediate.__getattribute__(src_type).nstructures >= i+1: #存在する構造か判断
                            f.write(f"{n_atoms}\n")
                            f.write(f"{name}\n")
                            f.writelines(intermediate.__getattribute__(src_type).structures[i])
                            f.write("\n")
            subprocess.Popen([jmol_path, f"{file}"], shell=True)
    except TypeError:
        pass

def make_graphml(datfile):
    with open(datfile,encoding="utf-8-sig") as f:
        l = f.readlines()
        save_path = l[0].strip()
        sheet_name = l[1].strip()
    eq_df = xw.sheets[sheet_name].range('A1').options(pd.DataFrame,expand='table',index=False).value.iloc[:, 0:6]
    eq_df = _df_type_conversion(eq_df,"node")
    ts_df = xw.sheets["TS"].range('A1').options(pd.DataFrame,expand='table',index=False).value.iloc[:, 0:9]
    ts_df = _df_type_conversion(ts_df,"edge")
    if "PT" in [str(sh.name) for sh in xw.sheets]:
        pt_df = xw.sheets["PT"].range('A1').options(pd.DataFrame,expand='table',index=False).value.iloc[:, 0:9]
        pt_df = _df_type_conversion(pt_df,"edge") if not pt_df.empty else False            
    else:
        pt_df = False
    grrm_analysis._make_graphml(eq_df,ts_df,pt_df,save_path)


def mk_xyz(sample,datfile):
    with open(datfile,encoding="utf-8-sig") as f:
        l = f.readlines()
        save_path = l[0].strip()
        sheet_name = l[1].strip()
        option_i = int(l[2].strip())
    eq_df = xw.sheets[sheet_name].range('A1').options(pd.DataFrame,expand='table',index=False).value.iloc[:, 0:5]
    eq_df = _df_type_conversion(eq_df,"node")
    eq_df= eq_df.sort_values(by=["group","node"]) #ソート
    print(eq_df)
    unique_eq_df = eq_df.drop_duplicates(subset='group') #ユニークなgroupを抽出
    if option_i == 0: #全EQ
        sample.make_xyz_file(file=save_path,group=None)
    elif option_i  == 1: #Group(全部)
        idx_list = list(eq_df["node"])
        group_list = list(eq_df["group"])
        sample.make_xyz_file(file=save_path,idx_list=idx_list,group_list=group_list)
    elif  option_i  == 2: #Group(代表)
        idx_list = list(unique_eq_df["node"])
        group_list = list(unique_eq_df["group"])
        sample.make_xyz_file(file=save_path,idx_list=idx_list,group_list=group_list)

def _str_or_int(obj):
    if obj is not None:
        try:
            obj = int(obj)
        except ValueError:
            obj = str(obj)
        return obj
    else:
        return np.nan

def _df_type_conversion(df,tabletype):
    """DataFrameの型変換を行なうtabletype='node'or'edge'"""
    if tabletype == "node":
        df = df.astype({
            'node':int,
            'name':str,
            'E/Hartree':float,
            'E/kJmol-1':float})
        df["group"] = [_str_or_int(i)for i in df["group"]]
    if tabletype == "edge":
        df = df.astype({
            'edge':int,
            'name':str,
            'E/Hartree':float,
            'E/kJmol-1':float,
            'forward/kJmol-1':float,
            'reverse/kJmol-1':float})
        df["source"] = [_str_or_int(i)for i in df["source"]]
        df["target"] = [_str_or_int(i)for i in df["target"]]
    return df

def _write_original_eq(eq_dict,pt_dict,ts_dict,folder):
    p = pathlib.Path(folder).parent
    all_dict = eq_dict | pt_dict | ts_dict
    with open(f"{p/'temp/original_dict.pickle'}","wb") as f:
        pickle.dump(all_dict,f)

def make_intermediate_obj(dir):
    """Intermidiateオブジェクトを作成"""
    list_log_files = xw.sheets["ini"].range('B2:B4').options(convert=np.array, expand='right',ndim=2).value.T
    if isinstance(list_log_files[0][0],str): #セルにデータが入っている場合，
        group_target = xw.sheets["ini"].range('B7').value 
        for i,(eq,ts,pt) in enumerate(list_log_files):
            pt = pt if not pt=="nan" else None
            folder = pathlib.Path(dir).parent
            eq_p = pathlib.Path(eq)
            pt_p = pathlib.Path(pt) if pt is not None else None
            ts_p = pathlib.Path(ts)
            eq_relative = eq_p.relative_to(folder)
            pt_relative = pt_p.relative_to(folder) if pt is not None else None
            ts_relative = ts_p.relative_to(folder)
            if i == 0: #初め
                sample = Intermediate(eq,ts,pt)
                eq_list = [f"EQ{j}({eq_relative})" for j in range(sample.eq.nstructures)]
                pt_list = [f"PT{j}({pt_relative})" for j in range(sample.pt.nstructures)] if pt is not None else []
                ts_list = [f"TS{j}({ts_relative})" for j in range(sample.ts.nstructures)]
            else:
                pre_sample = Intermediate(eq,ts,pt) #マージ
                eq_list += [f"EQ{j}({eq_relative})" for j in range(pre_sample.eq.nstructures)]
                pt_list += [f"PT{j}({pt_relative})" for j in range(pre_sample.pt.nstructures)] if pt is not None else []
                ts_list += [f"TS{j}({ts_relative})" for j in range(pre_sample.ts.nstructures)]
                sample += pre_sample
        eq_dict = {f"EQ{i}": j for i,j in enumerate(eq_list)}
        pt_dict = {f"PT{i}": j for i,j in enumerate(pt_list)}
        ts_dict = {f"TS{i}": j for i,j in enumerate(ts_list)}
        _write_original_eq(eq_dict,pt_dict,ts_dict,dir)
        if group_target:
            sample.grouping(target=group_target)
        else:
            sample.grouping()
        return sample
    else: #インポートするデータがない時
        return None

def _get_use_data():
    if "TS" in [str(sh.name) for sh in xw.sheets] and len(xw.sheets['TS'].tables)!=0:
        """TSシートが存在して且つTSシートにTableが存在する時"""
        ts_df = xw.sheets["TS"].range('A1').options(pd.DataFrame,expand='table',index=False).value.iloc[:, 0:9]
        ts_df = _df_type_conversion(ts_df,"edge")
        ts_false = ts_df[~ts_df["USE"]]
        ts_false_name = list(ts_false["name"])
    else:
        ts_false_name = []
    if "PT" in [str(sh.name) for sh in xw.sheets] and len(xw.sheets['PT'].tables)!=0:
        pt_df = xw.sheets["PT"].range('A1').options(pd.DataFrame,expand='table',index=False).value.iloc[:, 0:9]
        pt_df = _df_type_conversion(pt_df,"edge")
        pt_false = pt_df[~pt_df["USE"]]
        pt_false_name = list(pt_false["name"])
    else:
        pt_false_name = []
    return pt_false_name, ts_false_name

def _set_use_data(pt_false_name,ts_false_name,pt_df,ts_df):
    for name in pt_false_name:
        i = pt_df.reset_index().query(f'name == "{name}"').index[0]
        pt_df.loc[i, 'USE'] = False
    for name in ts_false_name:
        i = ts_df.reset_index().query(f'name == "{name}"').index[0]
        ts_df.loc[i, 'USE'] = False
    return pt_df,ts_df

def import_data(folder):
    """データをインポートのボタンを押した時"""
    def _df_to_table(df,sheetname,cell_name="A1"):
        """DataFrameをエクセルファイルに貼る"""
        sheet_names = [str(sh.name) for sh in xw.sheets]
        if sheetname in sheet_names:
            """指定のシートがある場合"""
            sheet = xw.sheets[sheetname]
            sheet.clear()
            if not df.empty:
                """かつ,dfが空でない場合"""
                sheet.range(cell_name).options(index=False).value = df
                tbl_range = sheet.range(cell_name).expand('table')
                sheet.api.ListObjects.Add(1, sheet.api.Range(tbl_range.address))   
    FileCheck = str(pathlib.Path(folder).parent/"temp"/"FileCheck.dat")
    try:
        sample = make_intermediate_obj(folder)
        if sample is None:
            with open(FileCheck,"w") as f:
                f.write("Error")
            return None
        write_pickle(folder,sample)
        pt_false_name, ts_false_name = _get_use_data() #USEがFalseの名前を取得
        eq_df,pt_df,ts_df = sample._make_data_for_excel_table()
        pt_df,ts_df = _set_use_data(pt_false_name, ts_false_name,pt_df,ts_df) #再度Falseを設定
        path_df = copy.deepcopy(eq_df)
        eq_df = eq_df.drop('USE', axis=1)#USEカラムを削除
        _df_to_table(eq_df,"EQ","A1")
        xw.sheets["EQ"].tables[0].name = "EQ" #Tableの名前を変更
        if xw.sheets['Path'].used_range.value is None:
            _df_to_table(path_df,"Path","A1")
            xw.sheets["Path"].tables[0].name = "Path"
        _df_to_table(ts_df,"TS","A1")
        xw.sheets["TS"].tables[0].name = "TS"
        if sample.pt.nstructures != 0:
            _df_to_table(pt_df,"PT","A1")
            xw.sheets["PT"].tables[0].name = "PT"
        with open(FileCheck,"w") as f:
            f.write("OK")
        return sample
    except ListLogFileError:
        with open(FileCheck,"w") as f:
            f.write("Error")
        return None

def read_ini_file(folder):
    p = pathlib.Path(folder)
    ini_path = p.with_name("setting.ini").absolute()
    config_ini = configparser.ConfigParser()
    config_ini.read(ini_path, encoding='utf-8')
    return config_ini

def group_name(eq_name,df):
    df = df.query(f'name == "{eq_name}"')
    return str(df["group"].iloc[0])

def _path_data_organization(paths,eq_df):
    paths = paths.values()
    paths = sorted(paths,key=lambda x: (x[0],len(x[1]))) #Ea順にソート
    paths = [i for i in paths if len(i[1]) != 0] #pathの長さが0のモノは削除
    max_len = max(list(map(lambda x:len(x[1]), paths)))
    path_table = []
    path_table.append(["Ea(kJ/mol)"]+[None]*max_len)
    for path in paths:
        if not path[1] == []:#パスがあれば
            empty = [None for _ in range(max_len-len(path[1]))] #空白はNoneで埋める
            g_name = group_name(path[1][-1],eq_df)
            path_table.append([g_name]+path[1]+empty) #パス
            path_table.append([path[0]]+path[2]+empty) #各エネルギー
    return path_table

def path(source, target,pt,group,priority,pseudo_energy):
    """反応経路を探す"""
    ###引数の検証###
    source = _str_or_int(source)
    if target is not None:
        target = _str_or_int(target)
    pt = int(pt)
    priority = int(priority)
    if priority == 0:
        priority = "energy"
    elif priority == 1:
        priority = "length"
    ###Tableのデータを取得###
    eq_df = xw.sheets["Path"].range('A1').options(pd.DataFrame,expand='table',index=False).value.iloc[:, 0:6]
    eq_df = _df_type_conversion(eq_df,"node")
    ts_df = xw.sheets["TS"].range('A1').options(pd.DataFrame,expand='table',index=False).value.iloc[:, 0:9]
    ts_df = _df_type_conversion(ts_df,"edge")
    if "PT" in [str(sh.name) for sh in xw.sheets] and len(xw.sheets['PT'].tables)!=0:
        """PTシートが存在して且つPTシートにTableが存在する時"""
        pt_df = xw.sheets["PT"].range('A1').options(pd.DataFrame,expand='table',index=False).value.iloc[:, 0:9]
        pt_df = _df_type_conversion(pt_df,"edge")
    else:
        pt_df = pd.DataFrame({})
    eq_n = len(eq_df)
    eq,edges,eq_energy,pt_energy,ts_energy = _make_data_for_search_reactionpath(eq_df,ts_df,group,pt,pt_df)
    barrier_and_path = _path_search(eq_n,edges, eq, source, target,group,priority,pseudo_cost=None)
    paths = _pseudo_energy_clc_and_data_organization(eq_n,barrier_and_path,eq,edges,source,target,group,priority,pseudo_energy,eq_energy,pt_energy,ts_energy,write_group_name=False)
    return _path_data_organization(paths,eq_df)

def prepare(data):
    def divide_data(data):
        """2要素ずつに分割"""
        divided_data = [data[i: i+2]for i in range(0, len(data), 2)]
        return divided_data
    def make_solid_data(divided_data):
        """{(1,2):{EQ1:[e,e]},(3,4):{TS2:[e,e],TS3:[e,e]},(5,6):{EQ2:[e,e],EQ1:[e,e]}}"""
        std_val = float(divided_data[0][1][0])
        solid_data = {}
        for reaction in divided_data:
            for i,(name,energy) in enumerate(zip(reaction[0],reaction[1]),start=1):
                if not energy is None and energy != "":
                     energy = float(energy)
                else:
                    continue
                if not (2*i-1,2*i) in solid_data.keys():
                    solid_data[(2*i-1,2*i)] = {name:[energy-std_val,energy-std_val]}
                else:
                    solid_data[(2*i-1,2*i)][name] = [energy-std_val,energy-std_val]
        return solid_data
    def make_dot_data(divided_data):
        """{(2,3):{EQ1-PT10:[ini_e,fin_e],EQ1-TS2:[ini_e,fin_e]},(4,5):{PT10-EQ2:[ini_e,fin_e],PT10-EQ3:[ini_e,fin_e]}"""
        dot_data = {}
        std_val = float(divided_data[0][1][0])
        for reaction in divided_data:
            for i,(name,fin_e) in enumerate(zip(reaction[0][1:],reaction[1][1:]),start=1):
                fin_n = 2*i+1
                fin_name = name
                if not fin_name is None and fin_name!="":
                    fin_e = float(fin_e)
                else:
                    continue
                for i,n in reversed(list(enumerate(reaction[0][:i]))):
                    if n is not None and fin_name!="":
                        ini_n = 2*i+2
                        ini_name = n
                        ini_e = float(reaction[1][i])
                        break
                if not (ini_n,fin_n) in dot_data.keys():
                    dot_data[(ini_n,fin_n)] = {f"{ini_name}-{fin_name}":[ini_e-std_val,fin_e-std_val]}
                else:
                    dot_data[(ini_n,fin_n)][f"{ini_name}-{fin_name}"] = [ini_e-std_val,fin_e-std_val]
        return dot_data
    def to_list_data(line_data):
        list_data = []
        dict_data = sorted(line_data.items(),key=lambda x:x[0])
        for (ini_i,fin_i),name_e_dict in dict_data:
            for name,(e_ini,e_fin) in name_e_dict.items():
                list_data.append([ini_i,fin_i,name,e_ini,e_fin])
        return list_data
    divided_data = divide_data(data)
    solid_data = make_solid_data(divided_data)
    dot_data = make_dot_data(divided_data)
    solid_data = to_list_data(solid_data)
    dot_data = to_list_data(dot_data)
    if len(solid_data) > len(dot_data):
        n = len(solid_data) - len(dot_data)
        dot_data += [[None]*5 for _ in range(n)]
    elif len(solid_data) < len(dot_data):
        n = len(dot_data) - len(solid_data)
        solid_data += [[None]*5 for _ in range(n)]
    data_table = [i+j for i,j in zip(solid_data,dot_data)]
    column = [["solid_x","","name","solid_y","","dot_x","","name","dot_y",""]]
    return column + data_table

def energy(structure):
    eq_df = xw.sheets["EQ"].range('A1').options(pd.DataFrame,expand='table',index=False).value.iloc[:, 0:5]
    pt_df = xw.sheets["PT"].range('A1').options(pd.DataFrame,expand='table',index=False).value.iloc[:, 0:8]
    ts_df = xw.sheets["TS"].range('A1').options(pd.DataFrame,expand='table',index=False).value.iloc[:, 0:8]
    energy_list = []
    for i in structure:
        e_list = []
        for j in i:
            if "EQ" in j: 
                df = eq_df.query(f'name == "{j}"')
                e = float(df["E/kJmol-1"])
            elif "PT" in j:
                df = pt_df.query(f'name == "{j}"')
                e = float(df["E/kJmol-1"])
            elif "TS" in j:
                df = ts_df.query(f'name == "{j}"')
                e = float(df["E/kJmol-1"])
            e_list.append(e)
        energy_list.append(e_list)
    return energy_list

def group(structure):
    eq_df = xw.sheets["Path"].range('A1').options(pd.DataFrame,expand='table',index=False).value.iloc[:, 0:5]
    name_list = [[group_name(j,eq_df) if "EQ" in j else "なし" for j in i] for i in structure] 
    return name_list

def original(structure,folder):
    p = pathlib.Path(folder).parent
    with open(f"{p/'temp/original_dict.pickle'}", "rb") as f:
        all_dict = pickle.load(f)
    return [[all_dict[j] for j in i] for i in structure]
        