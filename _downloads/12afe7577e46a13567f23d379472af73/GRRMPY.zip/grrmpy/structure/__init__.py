from grrmpy.structure.comfile import COM

__all__ = ["COM"]