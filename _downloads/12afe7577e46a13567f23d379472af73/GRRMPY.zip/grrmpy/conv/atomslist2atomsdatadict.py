def atomslist2atomsdatadict(atoms_list):
    return [atoms.todict() for atoms in atoms_list]