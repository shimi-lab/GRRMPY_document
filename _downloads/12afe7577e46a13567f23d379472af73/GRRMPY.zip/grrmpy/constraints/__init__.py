from grrmpy.constraints.constraints import ForProduct

__all__ = ["ForProduct"]
