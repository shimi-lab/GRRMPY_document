class Search():
    def __init__(self,eq_df,ts_df,pt_df=None):
        self.eq_df = eq_df
        self.ts_df = ts_df
        self.pt_df = pt_df
        
 